-- MegChatBox V5 starter schema for Supabase SQL Editor.
-- Run this in a new/test project first. Back up existing data before applying to a live project.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null check (char_length(username) between 1 and 24),
  full_name text not null default 'User',
  bio text not null default '',
  avatar_url text,
  role text not null default 'user' check (role in ('user','admin','owner')),
  is_verified boolean not null default false,
  username_private boolean not null default false,
  show_online boolean not null default true,
  show_last_seen boolean not null default true,
  last_seen timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.contacts (
  user_id uuid not null references public.profiles(id) on delete cascade,
  contact_id uuid not null references public.profiles(id) on delete cascade,
  nickname text,
  created_at timestamptz not null default now(),
  primary key(user_id, contact_id),
  check(user_id <> contact_id)
);

create table if not exists public.contact_requests (
  id uuid primary key default gen_random_uuid(),
  from_user uuid not null references public.profiles(id) on delete cascade,
  to_user uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check(status in ('pending','accepted','declined')),
  created_at timestamptz not null default now(),
  unique(from_user,to_user),
  check(from_user <> to_user)
);

create table if not exists public.chats (
  id uuid primary key default gen_random_uuid(),
  type text not null default 'direct' check(type in ('direct','group','channel')),
  title text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.chat_members (
  chat_id uuid not null references public.chats(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key(chat_id,user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  chat_id uuid not null references public.chats(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  content text not null default '',
  reply_to uuid references public.messages(id) on delete set null,
  edited_at timestamptz,
  deleted_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists messages_chat_created_idx on public.messages(chat_id, created_at desc);

create table if not exists public.saved_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  message_id uuid not null references public.messages(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(user_id,message_id)
);

create table if not exists public.communities (
  id uuid primary key default gen_random_uuid(),
  type text not null check(type in ('group','channel')),
  name text not null,
  username text unique,
  bio text not null default '',
  avatar_url text,
  cover_url text,
  visibility text not null default 'private' check(visibility in ('public','private')),
  join_requires_approval boolean not null default false,
  creator_id uuid not null references public.profiles(id) on delete restrict,
  created_at timestamptz not null default now()
);

create table if not exists public.community_members (
  community_id uuid not null references public.communities(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  member_role text not null default 'member' check(member_role in ('creator','admin','member')),
  permissions jsonb not null default '{}'::jsonb,
  joined_at timestamptz not null default now(),
  primary key(community_id,user_id)
);

create table if not exists public.app_admins (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  role text not null default 'admin',
  permissions jsonb not null default '{}'::jsonb,
  granted_by uuid references public.profiles(id) on delete set null,
  active_until timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  target_user_id uuid references public.profiles(id) on delete cascade,
  message_id uuid references public.messages(id) on delete cascade,
  community_id uuid references public.communities(id) on delete cascade,
  reason text not null,
  details text not null default '',
  status text not null default 'open' check(status in ('open','reviewing','resolved','dismissed')),
  reviewed_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  type text not null,
  title text not null,
  body text not null default '',
  payload jsonb not null default '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.admin_audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id) on delete set null,
  action text not null,
  target_user_id uuid references public.profiles(id) on delete set null,
  target_community_id uuid references public.communities(id) on delete set null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.device_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  device_label text not null default 'Unknown browser',
  last_active_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.contacts enable row level security;
alter table public.contact_requests enable row level security;
alter table public.chats enable row level security;
alter table public.chat_members enable row level security;
alter table public.messages enable row level security;
alter table public.saved_messages enable row level security;
alter table public.communities enable row level security;
alter table public.community_members enable row level security;
alter table public.app_admins enable row level security;
alter table public.reports enable row level security;
alter table public.notifications enable row level security;
alter table public.admin_audit_logs enable row level security;
alter table public.device_sessions enable row level security;

-- Basic policies for the starter build. Privileged role grants and moderation must be server-side.
drop policy if exists "profiles readable by authenticated users" on public.profiles;
create policy "profiles readable by authenticated users" on public.profiles for select to authenticated using (true);
drop policy if exists "users insert own profile" on public.profiles;
create policy "users insert own profile" on public.profiles for insert to authenticated with check (id = auth.uid() and role = 'user' and is_verified = false);
drop policy if exists "users update own profile" on public.profiles;
create policy "users update own profile" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists "contacts readable by owner" on public.contacts;
create policy "contacts readable by owner" on public.contacts for select to authenticated using (user_id = auth.uid());
drop policy if exists "contacts create self" on public.contacts;
create policy "contacts create self" on public.contacts for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "contacts remove self" on public.contacts;
create policy "contacts remove self" on public.contacts for delete to authenticated using (user_id = auth.uid());

drop policy if exists "requests visible to participants" on public.contact_requests;
create policy "requests visible to participants" on public.contact_requests for select to authenticated using (from_user = auth.uid() or to_user = auth.uid());
drop policy if exists "requests send as self" on public.contact_requests;
create policy "requests send as self" on public.contact_requests for insert to authenticated with check (from_user = auth.uid() and status = 'pending');
drop policy if exists "recipient can update request" on public.contact_requests;
create policy "recipient can update request" on public.contact_requests for update to authenticated using (to_user = auth.uid()) with check (to_user = auth.uid());

drop policy if exists "chat members can see their chats" on public.chats;
create policy "chat members can see their chats" on public.chats for select to authenticated using (exists(select 1 from public.chat_members m where m.chat_id=id and m.user_id=auth.uid()));
drop policy if exists "authenticated can create chat" on public.chats;
create policy "authenticated can create chat" on public.chats for insert to authenticated with check (created_by=auth.uid());
drop policy if exists "members can see membership" on public.chat_members;
create policy "members can see membership" on public.chat_members for select to authenticated using (exists(select 1 from public.chat_members m where m.chat_id=chat_id and m.user_id=auth.uid()));
drop policy if exists "creator can add initial members" on public.chat_members;
create policy "creator can add initial members" on public.chat_members for insert to authenticated with check (exists(select 1 from public.chats c where c.id=chat_id and c.created_by=auth.uid()) or user_id=auth.uid());

drop policy if exists "members can read messages" on public.messages;
create policy "members can read messages" on public.messages for select to authenticated using (exists(select 1 from public.chat_members m where m.chat_id=messages.chat_id and m.user_id=auth.uid()));
drop policy if exists "members can send messages" on public.messages;
create policy "members can send messages" on public.messages for insert to authenticated with check (sender_id=auth.uid() and exists(select 1 from public.chat_members m where m.chat_id=messages.chat_id and m.user_id=auth.uid()));
drop policy if exists "sender can update own message" on public.messages;
create policy "sender can update own message" on public.messages for update to authenticated using (sender_id=auth.uid()) with check (sender_id=auth.uid());

drop policy if exists "users manage own saved messages" on public.saved_messages;
create policy "users manage own saved messages" on public.saved_messages for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());

drop policy if exists "public communities or own membership" on public.communities;
create policy "public communities or own membership" on public.communities for select to authenticated using (visibility='public' or creator_id=auth.uid() or exists(select 1 from public.community_members cm where cm.community_id=id and cm.user_id=auth.uid()));
drop policy if exists "create own communities" on public.communities;
create policy "create own communities" on public.communities for insert to authenticated with check (creator_id=auth.uid());
drop policy if exists "creator update community" on public.communities;
create policy "creator update community" on public.communities for update to authenticated using (creator_id=auth.uid()) with check (creator_id=auth.uid());
drop policy if exists "members see community members" on public.community_members;
create policy "members see community members" on public.community_members for select to authenticated using (user_id=auth.uid() or exists(select 1 from public.community_members cm where cm.community_id=community_id and cm.user_id=auth.uid()));
drop policy if exists "users join public communities" on public.community_members;
create policy "users join public communities" on public.community_members for insert to authenticated with check (user_id=auth.uid() and exists(select 1 from public.communities c where c.id=community_id and c.visibility='public'));
drop policy if exists "users see own admin row" on public.app_admins;
create policy "users see own admin row" on public.app_admins for select to authenticated using (user_id=auth.uid());
drop policy if exists "reporter creates report" on public.reports;
create policy "reporter creates report" on public.reports for insert to authenticated with check (reporter_id=auth.uid());
drop policy if exists "reporter sees own reports" on public.reports;
create policy "reporter sees own reports" on public.reports for select to authenticated using (reporter_id=auth.uid());
drop policy if exists "users see own notifications" on public.notifications;
create policy "users see own notifications" on public.notifications for select to authenticated using (user_id=auth.uid());
drop policy if exists "users update own notifications" on public.notifications;
create policy "users update own notifications" on public.notifications for update to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
drop policy if exists "admins see audit logs" on public.admin_audit_logs;
create policy "admins see audit logs" on public.admin_audit_logs for select to authenticated using (actor_id=auth.uid());
drop policy if exists "users see own devices" on public.device_sessions;
create policy "users see own devices" on public.device_sessions for select to authenticated using (user_id=auth.uid());

-- Create your first owner only after the account exists, by running this as project owner in SQL Editor:
-- update public.profiles set role='owner' where username='your_owner_username';
-- Never allow the browser to set role='owner' or grant admin permissions directly.
